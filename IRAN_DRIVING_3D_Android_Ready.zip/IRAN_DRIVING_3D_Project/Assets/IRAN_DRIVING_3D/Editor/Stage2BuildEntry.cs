#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;

public static class Stage2BuildEntry
{
    public static void Build()
    {
        Directory.CreateDirectory("Assets/IRAN_DRIVING_3D/Scenes");
        AssetDatabase.Refresh();
        Stage2SceneBuilder.Build();
        const string scenePath = "Assets/IRAN_DRIVING_3D/Scenes/Stage2_City_Test.unity";
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(scenePath, true) };
        AssetDatabase.SaveAssets();
        EditorSceneManager.SaveOpenScenes();
        UnityEngine.Debug.Log("Android build scene prepared: " + scenePath);
    }
}
#endif
