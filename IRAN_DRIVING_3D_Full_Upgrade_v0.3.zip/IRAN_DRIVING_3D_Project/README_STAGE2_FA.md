# IRAN DRIVING 3D — مرحله دوم: صحنه شهری قابل‌بازی

این بسته به بسته Starter 0.1 اضافه می‌شود. هدف، ساخت یک صحنه آزمایشی شهری با جاده شبکه‌ای، ساختمان‌های ساده، خودروی پایه، دوربین و کنترل لمسی است.

## نصب
1. پروژه Unity 6 با قالب Universal 3D (URP) را باز کنید.
2. اگر Starter 0.1 را نصب نکرده‌اید، ابتدا آن را نصب کنید.
3. پوشه `Assets/IRAN_DRIVING_3D` این بسته را به `Assets` پروژه کپی کنید.
4. از منوی Unity گزینه `IRAN DRIVING 3D > Build Stage 2 Test Scene` را انتخاب کنید.
5. صحنه ساخته‌شده در `Assets/IRAN_DRIVING_3D/Scenes/Stage2_City_Test.unity` باز می‌شود.
6. روی Play بزنید. صحنه برای تست اولیه کنترل و مقیاس است؛ ظاهر ساختمان‌ها فعلاً بلوکی و موقت است.

## کنترل
- دکمه چپ و راست: فرمان
- گاز: حرکت
- ترمز: توقف / کاهش سرعت
- ترمز دستی: قفل چرخ‌های عقب

## نکات
- این ابزار از Primitiveهای Unity استفاده می‌کند؛ مدل نهایی ماشین و ساختمان‌ها هنوز باید با Assetهای سه‌بعدی باکیفیت جایگزین شوند.
- برای عملکرد درست، EventSystem و Canvas در صحنه ساخته می‌شوند.
- اسکریپت‌های Starter 0.1 مانند `ArcadeCarController`، `FollowCamera`، `HoldButton` و `SpeedometerUI` باید در پروژه موجود باشند.
- اگر TextMeshPro درخواست Import Essentials کرد، گزینه Import TMP Essentials را انتخاب کنید.
- این مرحله APK آماده نیست؛ برای خروجی Android باید Android Build Support شامل SDK/NDK و OpenJDK در Unity Hub نصب باشد.
