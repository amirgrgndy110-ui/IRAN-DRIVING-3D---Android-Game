using TMPro;
using UnityEngine;

namespace IranDriving3D
{
    public class SpeedometerUI : MonoBehaviour
    {
        public ArcadeCarController car;
        public TMP_Text speedText;

        private void Update()
        {
            if (!car || !speedText) return;
            speedText.text = Mathf.RoundToInt(car.SpeedKmh).ToString("000");
        }
    }
}
