using UnityEngine;

namespace IranDriving3D
{
    public class VehicleCameraSwitcher : MonoBehaviour
    {
        public Camera chaseCamera;
        public Camera cockpitCamera;
        public KeyCode editorToggleKey = KeyCode.C;
        private bool cockpit;

        public void ToggleCamera()
        {
            cockpit = !cockpit;
            Apply();
        }

        private void Update()
        {
            if (Application.isEditor && Input.GetKeyDown(editorToggleKey))
                ToggleCamera();
        }

        private void Apply()
        {
            if (chaseCamera) chaseCamera.enabled = !cockpit;
            if (cockpitCamera) cockpitCamera.enabled = cockpit;
        }
    }
}
