using UnityEngine;

namespace IranDriving3D
{
    [RequireComponent(typeof(Rigidbody))]
    public class ArcadeCarController : MonoBehaviour
    {
        [Header("Wheel Colliders")]
        public WheelCollider frontLeft, frontRight, rearLeft, rearRight;
        [Header("Wheel Visuals")]
        public Transform frontLeftMesh, frontRightMesh, rearLeftMesh, rearRightMesh;

        [Header("Vehicle Setup")]
        public float vehicleMass = 2100f;
        public Transform centerOfMass;
        public float maxSteerAngle = 32f;
        public float highSpeedSteerAngle = 9f;
        public float steeringFadeSpeed = 150f;
        public float downforce = 65f;
        public float antiRollFront = 6500f;
        public float antiRollRear = 5200f;

        [Header("Engine")]
        public float idleRPM = 850f;
        public float maxRPM = 5600f;
        public float maxEngineTorque = 360f;
        public AnimationCurve torqueCurve = new AnimationCurve(
            new Keyframe(0f, 0.72f), new Keyframe(0.35f, 1f),
            new Keyframe(0.72f, 0.88f), new Keyframe(1f, 0.62f));
        public float finalDrive = 3.9f;
        public float[] forwardGearRatios = { 3.8f, 2.2f, 1.5f, 1.0f, 0.78f };
        public float reverseGearRatio = 3.4f;
        public float shiftUpRPM = 4900f;
        public float shiftDownRPM = 1700f;
        public float drivetrainEfficiency = 0.86f;

        [Header("Brakes")]
        public float maxBrakeTorque = 3600f;
        [Range(0.1f, 0.9f)] public float frontBrakeBias = 0.62f;
        public float handbrakeTorque = 5200f;

        [Header("Assists")]
        public bool absEnabled = true;
        public bool tcsEnabled = true;
        public bool espEnabled = true;
        public float absSlipThreshold = 0.42f;
        public float tcsSlipThreshold = 0.35f;
        public float espSlipThreshold = 0.48f;
        [Range(0f, 1f)] public float assistStrength = 0.65f;

        [Header("Optional Lights")]
        public Light[] headLights;
        public Light[] brakeLights;
        public Light[] reverseLights;

        [Header("Optional Audio")]
        public AudioSource engineAudio;
        public AudioSource tireAudio;
        public float enginePitchMin = 0.8f;
        public float enginePitchMax = 2.0f;

        private Rigidbody rb;
        private float throttleInput, steeringInput, brakeInput;
        private bool handbrakeInput, headlightsOn;
        private int gear = 1;
        private float engineRPM;
        private float shiftTimer;
        private const float ShiftDuration = 0.28f;

        public float SpeedKmh => rb ? rb.velocity.magnitude * 3.6f : 0f;
        public float EngineRPM => engineRPM;
        public int CurrentGear => gear;
        public bool IsReverse => gear < 0;

        private void Awake()
        {
            rb = GetComponent<Rigidbody>();
            rb.mass = vehicleMass;
            rb.interpolation = RigidbodyInterpolation.Interpolate;
            rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            if (centerOfMass)
                rb.centerOfMass = transform.InverseTransformPoint(centerOfMass.position);
            engineRPM = idleRPM;
        }

        public void SetThrottle(float value) => throttleInput = Mathf.Clamp01(value);
        public void SetSteering(float value) => steeringInput = Mathf.Clamp(value, -1f, 1f);
        public void SetBrake(bool value) => brakeInput = value ? 1f : 0f;
        public void SetBrakeAmount(float value) => brakeInput = Mathf.Clamp01(value);
        public void SetHandbrake(bool value) => handbrakeInput = value;
        public void ToggleHeadlights()
        {
            headlightsOn = !headlightsOn;
            SetLights(headLights, headlightsOn);
        }

        private void FixedUpdate()
        {
            if (!WheelsReady()) return;

            shiftTimer = Mathf.Max(0f, shiftTimer - Time.fixedDeltaTime);
            UpdateEngineAndGears();

            float speed = SpeedKmh;
            float steerLimit = Mathf.Lerp(maxSteerAngle, highSpeedSteerAngle,
                Mathf.Clamp01(speed / Mathf.Max(1f, steeringFadeSpeed)));
            float steer = steeringInput * steerLimit;
            frontLeft.steerAngle = steer;
            frontRight.steerAngle = steer;

            ApplyDriveTorque();
            ApplyBrakes();
            ApplyAntiRoll(frontLeft, frontRight, antiRollFront);
            ApplyAntiRoll(rearLeft, rearRight, antiRollRear);

            rb.AddForce(-transform.up * downforce * rb.velocity.sqrMagnitude * 0.015f,
                ForceMode.Force);

            ApplyESP();
            UpdateWheelVisuals();
            UpdateLights();
            UpdateAudio();
        }

        private void UpdateEngineAndGears()
        {
            float averageWheelRPM = (Mathf.Abs(rearLeft.rpm) + Mathf.Abs(rearRight.rpm)) * 0.5f;
            float ratio = CurrentRatio();
            float coupledRPM = averageWheelRPM * Mathf.Abs(ratio) * finalDrive;
            float targetRPM = Mathf.Max(idleRPM, coupledRPM);

            if (shiftTimer <= 0f && gear > 0 && forwardGearRatios != null && forwardGearRatios.Length > 0)
            {
                if (engineRPM > shiftUpRPM && gear < forwardGearRatios.Length)
                    ShiftTo(gear + 1);
                else if (engineRPM < shiftDownRPM && gear > 1)
                    ShiftTo(gear - 1);
            }

            if (shiftTimer > 0f)
                targetRPM = Mathf.Lerp(idleRPM, targetRPM, 0.45f);

            engineRPM = Mathf.Clamp(Mathf.Lerp(engineRPM, targetRPM + throttleInput * 450f,
                Time.fixedDeltaTime * 5f), idleRPM, maxRPM);
        }

        private void ShiftTo(int nextGear)
        {
            gear = nextGear;
            shiftTimer = ShiftDuration;
        }

        private float CurrentRatio()
        {
            if (gear < 0) return -Mathf.Abs(reverseGearRatio);
            if (gear == 0) return 0f;
            if (forwardGearRatios == null || forwardGearRatios.Length == 0) return 1f;
            return forwardGearRatios[Mathf.Clamp(gear - 1, 0, forwardGearRatios.Length - 1)];
        }

        private void ApplyDriveTorque()
        {
            float ratio = CurrentRatio();
            if (Mathf.Abs(ratio) < 0.001f || shiftTimer > 0f)
            {
                rearLeft.motorTorque = rearRight.motorTorque = 0f;
                return;
            }

            float rpm01 = Mathf.InverseLerp(idleRPM, maxRPM, engineRPM);
            float engineTorque = maxEngineTorque * torqueCurve.Evaluate(rpm01);
            float wheelTorque = engineTorque * ratio * finalDrive * drivetrainEfficiency;
            float assist = 1f;

            if (tcsEnabled && throttleInput > 0.05f)
            {
                WheelHit hit;
                bool slip = (rearLeft.GetGroundHit(out hit) && Mathf.Abs(hit.forwardSlip) > tcsSlipThreshold) ||
                            (rearRight.GetGroundHit(out hit) && Mathf.Abs(hit.forwardSlip) > tcsSlipThreshold);
                if (slip) assist = 1f - assistStrength * 0.7f;
            }

            float direction = gear < 0 ? -1f : 1f;
            float torque = wheelTorque * throttleInput * assist * direction * 0.5f;
            rearLeft.motorTorque = torque;
            rearRight.motorTorque = torque;
        }

        private void ApplyBrakes()
        {
            float service = brakeInput * maxBrakeTorque;
            float front = service * frontBrakeBias;
            float rear = service * (1f - frontBrakeBias);
            float rearHandbrake = handbrakeInput ? handbrakeTorque : 0f;

            frontLeft.brakeTorque = GetABSBrake(frontLeft, front);
            frontRight.brakeTorque = GetABSBrake(frontRight, front);
            rearLeft.brakeTorque = Mathf.Max(GetABSBrake(rearLeft, rear), rearHandbrake);
            rearRight.brakeTorque = Mathf.Max(GetABSBrake(rearRight, rear), rearHandbrake);
        }

        private float GetABSBrake(WheelCollider wheel, float requested)
        {
            if (!absEnabled || requested <= 0f) return requested;
            if (wheel.GetGroundHit(out WheelHit hit) && Mathf.Abs(hit.forwardSlip) > absSlipThreshold)
                return requested * (1f - assistStrength * 0.65f);
            return requested;
        }

        private void ApplyAntiRoll(WheelCollider left, WheelCollider right, float force)
        {
            bool groundedL = left.GetGroundHit(out WheelHit hitL);
            bool groundedR = right.GetGroundHit(out WheelHit hitR);
            float travelL = groundedL ? (-left.transform.InverseTransformPoint(hitL.point).y - left.radius) / left.suspensionDistance : 1f;
            float travelR = groundedR ? (-right.transform.InverseTransformPoint(hitR.point).y - right.radius) / right.suspensionDistance : 1f;
            float antiRollForce = (travelL - travelR) * force;

            if (groundedL)
                rb.AddForceAtPosition(left.transform.up * -antiRollForce, left.transform.position);
            if (groundedR)
                rb.AddForceAtPosition(right.transform.up * antiRollForce, right.transform.position);
        }

        private void ApplyESP()
        {
            if (!espEnabled || SpeedKmh < 18f) return;
            Vector3 localVelocity = transform.InverseTransformDirection(rb.velocity);
            float lateralRatio = Mathf.Abs(localVelocity.x) / Mathf.Max(1f, Mathf.Abs(localVelocity.z));
            if (lateralRatio > espSlipThreshold)
            {
                float correction = Mathf.Clamp01((lateralRatio - espSlipThreshold) * assistStrength);
                rb.AddForce(-transform.right * Mathf.Sign(localVelocity.x) * correction * 3.5f,
                    ForceMode.Acceleration);
                rearLeft.motorTorque *= (1f - correction * 0.35f);
                rearRight.motorTorque *= (1f - correction * 0.35f);
            }
        }

        private void UpdateWheelVisuals()
        {
            UpdateWheel(frontLeft, frontLeftMesh);
            UpdateWheel(frontRight, frontRightMesh);
            UpdateWheel(rearLeft, rearLeftMesh);
            UpdateWheel(rearRight, rearRightMesh);
        }

        private void UpdateWheel(WheelCollider wheel, Transform visual)
        {
            if (!wheel || !visual) return;
            wheel.GetWorldPose(out Vector3 pos, out Quaternion rot);
            visual.SetPositionAndRotation(pos, rot);
        }

        private void UpdateLights()
        {
            bool braking = brakeInput > 0.05f || handbrakeInput;
            SetLights(brakeLights, braking);
            SetLights(reverseLights, gear < 0);
        }

        private void UpdateAudio()
        {
            if (engineAudio)
            {
                engineAudio.pitch = Mathf.Lerp(enginePitchMin, enginePitchMax,
                    Mathf.InverseLerp(idleRPM, maxRPM, engineRPM));
                if (!engineAudio.isPlaying) engineAudio.Play();
            }

            if (tireAudio)
            {
                bool slipping = handbrakeInput || Mathf.Abs(steeringInput) > 0.65f && SpeedKmh > 35f;
                if (slipping && !tireAudio.isPlaying) tireAudio.Play();
                if (!slipping && tireAudio.isPlaying) tireAudio.Stop();
            }
        }

        private static void SetLights(Light[] lights, bool state)
        {
            if (lights == null) return;
            foreach (Light lightSource in lights)
                if (lightSource) lightSource.enabled = state;
        }

        private bool WheelsReady()
        {
            return frontLeft && frontRight && rearLeft && rearRight;
        }
    }
}
