using TMPro;
using UnityEngine;

namespace IranDriving3D
{
    public class VehicleDashboardUI : MonoBehaviour
    {
        public ArcadeCarController vehicle;
        public TMP_Text speedText;
        public TMP_Text rpmText;
        public TMP_Text gearText;

        private void Update()
        {
            if (!vehicle) return;
            if (speedText) speedText.text = Mathf.RoundToInt(vehicle.SpeedKmh).ToString("000") + " km/h";
            if (rpmText) rpmText.text = Mathf.RoundToInt(vehicle.EngineRPM).ToString("0000") + " RPM";
            if (gearText) gearText.text = vehicle.CurrentGear < 0 ? "R" : vehicle.CurrentGear == 0 ? "N" : "D" + vehicle.CurrentGear;
        }
    }
}
