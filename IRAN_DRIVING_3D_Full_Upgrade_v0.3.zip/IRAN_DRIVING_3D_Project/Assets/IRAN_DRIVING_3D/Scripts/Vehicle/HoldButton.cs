using UnityEngine;
using UnityEngine.EventSystems;

namespace IranDriving3D
{
    public class HoldButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
    {
        public enum ControlType { Throttle, Brake, Handbrake, SteerLeft, SteerRight }

        public ControlType controlType;
        public ArcadeCarController car;

        public void OnPointerDown(PointerEventData eventData) => Apply(true);
        public void OnPointerUp(PointerEventData eventData) => Apply(false);
        public void OnPointerExit(PointerEventData eventData) => Apply(false);

        private void Apply(bool pressed)
        {
            if (!car) return;

            switch (controlType)
            {
                case ControlType.Throttle:
                    car.SetThrottle(pressed ? 1f : 0f);
                    break;
                case ControlType.Brake:
                    car.SetBrake(pressed);
                    break;
                case ControlType.Handbrake:
                    car.SetHandbrake(pressed);
                    break;
                case ControlType.SteerLeft:
                    car.SetSteering(pressed ? -1f : 0f);
                    break;
                case ControlType.SteerRight:
                    car.SetSteering(pressed ? 1f : 0f);
                    break;
            }
        }
    }
}
