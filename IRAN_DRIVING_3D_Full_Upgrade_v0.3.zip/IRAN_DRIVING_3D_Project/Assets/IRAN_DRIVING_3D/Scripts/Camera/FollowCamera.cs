using UnityEngine;

namespace IranDriving3D
{
    public class FollowCamera : MonoBehaviour
    {
        public Transform target;
        public Vector3 offset = new Vector3(0f, 4.2f, -7.5f);
        public float positionSmooth = 7f;
        public float rotationSmooth = 8f;
        public float lookHeight = 1.2f;

        private void LateUpdate()
        {
            if (!target) return;

            Vector3 desiredPosition = target.TransformPoint(offset);
            transform.position = Vector3.Lerp(
                transform.position, desiredPosition,
                1f - Mathf.Exp(-positionSmooth * Time.deltaTime));

            Vector3 lookPoint = target.position + target.up * lookHeight;
            Quaternion desiredRotation = Quaternion.LookRotation(lookPoint - transform.position, Vector3.up);
            transform.rotation = Quaternion.Slerp(
                transform.rotation, desiredRotation,
                1f - Mathf.Exp(-rotationSmooth * Time.deltaTime));
        }
    }
}
