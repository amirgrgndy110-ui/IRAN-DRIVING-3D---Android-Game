using UnityEngine;

namespace IranDriving3D
{
    public class Stage2CityGenerator : MonoBehaviour
    {
        [Header("Grid")]
        [Min(2)] public int blocksX = 5;
        [Min(2)] public int blocksZ = 5;
        [Min(30f)] public float blockSize = 55f;
        [Min(8f)] public float roadWidth = 12f;
        public int randomSeed = 2026;

        [Header("Buildings")]
        public Vector2 buildingHeight = new Vector2(12f, 48f);
        public Vector2 buildingFootprint = new Vector2(12f, 22f);
        public Material roadMaterial;
        public Material buildingMaterial;
        public Material markingMaterial;

        [ContextMenu("Generate City")]
        public void GenerateCity()
        {
            ClearGenerated();
            Random.InitState(randomSeed);

            Transform roads = CreateGroup("Roads");
            Transform buildings = CreateGroup("Buildings");
            Transform details = CreateGroup("Road Details");

            float totalX = blocksX * blockSize + (blocksX + 1) * roadWidth;
            float totalZ = blocksZ * blockSize + (blocksZ + 1) * roadWidth;
            float startX = -totalX * 0.5f;
            float startZ = -totalZ * 0.5f;

            // Main road strips, continuous across the test district.
            for (int x = 0; x <= blocksX; x++)
            {
                float px = startX + roadWidth * 0.5f + x * (blockSize + roadWidth);
                CreateCube("Road_NS_" + x, roads, new Vector3(px, -0.12f, 0),
                    new Vector3(roadWidth, 0.2f, totalZ), roadMaterial, true);
            }

            for (int z = 0; z <= blocksZ; z++)
            {
                float pz = startZ + roadWidth * 0.5f + z * (blockSize + roadWidth);
                CreateCube("Road_EW_" + z, roads, new Vector3(0, -0.11f, pz),
                    new Vector3(totalX, 0.2f, roadWidth), roadMaterial, true);
            }

            // Dashed center markings on the larger road strips.
            for (int x = 0; x <= blocksX; x++)
            {
                float px = startX + roadWidth * 0.5f + x * (blockSize + roadWidth);
                for (float z = startZ + 5f; z < -startZ - 5f; z += 13f)
                    CreateCube("Line", details, new Vector3(px, 0.015f, z),
                        new Vector3(0.18f, 0.025f, 5f), markingMaterial, false);
            }

            for (int z = 0; z <= blocksZ; z++)
            {
                float pz = startZ + roadWidth * 0.5f + z * (blockSize + roadWidth);
                for (float x = startX + 5f; x < -startX - 5f; x += 13f)
                    CreateCube("Line", details, new Vector3(x, 0.02f, pz),
                        new Vector3(5f, 0.025f, 0.18f), markingMaterial, false);
            }

            // Buildings occupy the blocks, leaving a small perimeter margin.
            for (int x = 0; x < blocksX; x++)
            for (int z = 0; z < blocksZ; z++)
            {
                float bx = startX + roadWidth + x * (blockSize + roadWidth) + blockSize * 0.5f;
                float bz = startZ + roadWidth + z * (blockSize + roadWidth) + blockSize * 0.5f;
                int count = Random.Range(2, 5);

                for (int i = 0; i < count; i++)
                {
                    float w = Random.Range(buildingFootprint.x, buildingFootprint.y);
                    float d = Random.Range(buildingFootprint.x, buildingFootprint.y);
                    float h = Random.Range(buildingHeight.x, buildingHeight.y);
                    float ox = Random.Range(-blockSize * 0.22f, blockSize * 0.22f);
                    float oz = Random.Range(-blockSize * 0.22f, blockSize * 0.22f);
                    CreateCube("Building_" + x + "_" + z + "_" + i, buildings,
                        new Vector3(bx + ox, h * 0.5f, bz + oz),
                        new Vector3(w, h, d), buildingMaterial, true);
                }
            }
        }

        private Transform CreateGroup(string groupName)
        {
            GameObject group = new GameObject(groupName);
            group.transform.SetParent(transform, false);
            return group.transform;
        }

        private void CreateCube(string objectName, Transform parent, Vector3 pos,
            Vector3 scale, Material mat, bool collider)
        {
            GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = objectName;
            go.transform.SetParent(parent, true);
            go.transform.position = pos;
            go.transform.localScale = scale;
            if (mat) go.GetComponent<Renderer>().sharedMaterial = mat;
            if (!collider)
            {
                Collider c = go.GetComponent<Collider>();
                if (c) DestroyImmediate(c);
            }
        }

        private void ClearGenerated()
        {
            for (int i = transform.childCount - 1; i >= 0; i--)
                DestroyImmediate(transform.GetChild(i).gameObject);
        }
    }
}
