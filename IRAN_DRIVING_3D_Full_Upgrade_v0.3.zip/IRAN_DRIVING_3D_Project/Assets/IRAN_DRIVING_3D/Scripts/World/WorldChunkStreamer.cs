using UnityEngine;

namespace IranDriving3D
{
    // Add this component to an empty WorldChunks object.
    // Assign chunk roots in the Inspector. Keep chunks as separate scene objects.
    public class WorldChunkStreamer : MonoBehaviour
    {
        public Transform player;
        public GameObject[] chunks;
        public float activationDistance = 450f;
        public float refreshInterval = 0.5f;

        private float timer;

        private void Start() => RefreshChunks();

        private void Update()
        {
            if (!player || chunks == null) return;
            timer += Time.deltaTime;
            if (timer >= refreshInterval)
            {
                timer = 0f;
                RefreshChunks();
            }
        }

        public void RefreshChunks()
        {
            if (!player || chunks == null) return;

            foreach (GameObject chunk in chunks)
            {
                if (!chunk) continue;
                float distance = Vector3.Distance(player.position, chunk.transform.position);
                bool shouldBeActive = distance <= activationDistance;
                if (chunk.activeSelf != shouldBeActive)
                    chunk.SetActive(shouldBeActive);
            }
        }
    }
}
