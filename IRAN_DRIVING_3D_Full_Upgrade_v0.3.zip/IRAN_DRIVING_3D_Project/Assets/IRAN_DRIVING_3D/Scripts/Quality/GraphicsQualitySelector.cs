using UnityEngine;

namespace IranDriving3D
{
    public class GraphicsQualitySelector : MonoBehaviour
    {
        // Create matching quality levels in Project Settings > Quality.
        public void SetPerformance() => SetLevel(0);
        public void SetBalanced() => SetLevel(1);
        public void SetUltra() => SetLevel(2);

        private void SetLevel(int level)
        {
            int safeLevel = Mathf.Clamp(level, 0, QualitySettings.names.Length - 1);
            QualitySettings.SetQualityLevel(safeLevel, true);
            PlayerPrefs.SetInt("graphics_quality", safeLevel);
            PlayerPrefs.Save();
        }

        private void Start()
        {
            if (PlayerPrefs.HasKey("graphics_quality"))
                SetLevel(PlayerPrefs.GetInt("graphics_quality"));
        }
    }
}
