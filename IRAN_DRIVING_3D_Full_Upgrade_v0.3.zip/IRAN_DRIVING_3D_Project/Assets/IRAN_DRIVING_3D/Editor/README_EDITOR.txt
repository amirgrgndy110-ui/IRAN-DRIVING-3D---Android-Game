این پوشه ابزار Editor است. فایل Stage2SceneBuilder.cs باید داخل پوشه Editor باقی بماند تا منوی ساخت صحنه در Unity ظاهر شود.
