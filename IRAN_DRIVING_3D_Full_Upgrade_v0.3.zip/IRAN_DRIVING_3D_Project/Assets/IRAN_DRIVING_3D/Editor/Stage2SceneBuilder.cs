#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using TMPro;
using IranDriving3D;

public static class Stage2SceneBuilder
{
    [MenuItem("IRAN DRIVING 3D/Build Stage 2 Test Scene")]
    public static void Build()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);

        Material road = MakeMaterial("Road_Asphalt", new Color(0.12f, 0.13f, 0.15f));
        Material building = MakeMaterial("Building_Blockout", new Color(0.32f, 0.39f, 0.48f));
        Material marking = MakeMaterial("Road_Marking", new Color(0.88f, 0.86f, 0.72f));
        Material carPaint = MakeMaterial("Car_Paint_Test", new Color(0.75f, 0.08f, 0.045f));
        Material tire = MakeMaterial("Tire_Rubber", new Color(0.035f, 0.035f, 0.04f));

        GameObject city = new GameObject("City_Generated");
        var generator = city.AddComponent<Stage2CityGenerator>();
        generator.blocksX = 5;
        generator.blocksZ = 5;
        generator.roadMaterial = road;
        generator.buildingMaterial = building;
        generator.markingMaterial = marking;
        generator.GenerateCity();

        GameObject car = new GameObject("PlayerCar");
        car.transform.position = new Vector3(-100.5f, 1.1f, -100.5f);
        var rb = car.AddComponent<Rigidbody>();
        rb.mass = 1250f;
        rb.drag = 0.02f;
        rb.angularDrag = 0.6f;
        rb.centerOfMass = new Vector3(0f, -0.45f, 0f);

        MakePart("Body", car.transform, new Vector3(0f, 0.45f, 0f),
            new Vector3(2f, 0.65f, 4.2f), carPaint);
        MakePart("Cabin", car.transform, new Vector3(0f, 1.0f, -0.25f),
            new Vector3(1.65f, 0.75f, 2.0f), carPaint);

        var controller = car.AddComponent<ArcadeCarController>();
        controller.motorTorque = 1700f;
        controller.maxSpeedKmh = 160f;

        Transform[] wheelMeshes = new Transform[4];
        WheelCollider[] wheels = new WheelCollider[4];
        Vector3[] positions = {
            new Vector3(-0.95f, 0.05f, 1.35f),
            new Vector3(0.95f, 0.05f, 1.35f),
            new Vector3(-0.95f, 0.05f, -1.35f),
            new Vector3(0.95f, 0.05f, -1.35f)
        };

        for (int i = 0; i < 4; i++)
        {
            GameObject wc = new GameObject("WheelCollider_" + i);
            wc.transform.SetParent(car.transform, false);
            wc.transform.localPosition = positions[i];
            WheelCollider wheel = wc.AddComponent<WheelCollider>();
            wheel.radius = 0.36f;
            wheel.mass = 20f;
            wheel.suspensionDistance = 0.18f;
            JointSpring spring = wheel.suspensionSpring;
            spring.spring = 35000f;
            spring.damper = 4500f;
            wheel.suspensionSpring = spring;
            wheel.forceAppPointDistance = 0.1f;
            wheels[i] = wheel;

            GameObject mesh = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            mesh.name = "WheelMesh_" + i;
            mesh.transform.SetParent(car.transform, false);
            mesh.transform.localPosition = positions[i];
            mesh.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
            mesh.transform.localScale = new Vector3(0.72f, 0.18f, 0.72f);
            mesh.GetComponent<Renderer>().sharedMaterial = tire;
            Object.DestroyImmediate(mesh.GetComponent<Collider>());
            wheelMeshes[i] = mesh.transform;
        }

        controller.frontLeft = wheels[0];
        controller.frontRight = wheels[1];
        controller.rearLeft = wheels[2];
        controller.rearRight = wheels[3];
        controller.frontLeftMesh = wheelMeshes[0];
        controller.frontRightMesh = wheelMeshes[1];
        controller.rearLeftMesh = wheelMeshes[2];
        controller.rearRightMesh = wheelMeshes[3];

        GameObject cam = Camera.main ? Camera.main.gameObject : new GameObject("Main Camera");
        cam.tag = "MainCamera";
        var camera = cam.GetComponent<Camera>();
        if (!camera) camera = cam.AddComponent<Camera>();
        cam.transform.position = car.transform.position + new Vector3(0f, 4.2f, -7.5f);
        var follow = cam.GetComponent<FollowCamera>();
        if (!follow) follow = cam.AddComponent<FollowCamera>();
        follow.target = car.transform;

        BuildCanvas(controller);

        GameObject light = new GameObject("Sun");
        light.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
        var directional = light.AddComponent<Light>();
        directional.type = LightType.Directional;
        directional.intensity = 1.15f;

        EditorSceneManager.SaveScene(scene,
            "Assets/IRAN_DRIVING_3D/Scenes/Stage2_City_Test.unity");
        AssetDatabase.SaveAssets();
        Debug.Log("IRAN DRIVING 3D Stage 2 test scene created.");
    }

    private static Material MakeMaterial(string name, Color color)
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (!shader) shader = Shader.Find("Standard");
        var mat = new Material(shader) { name = name, color = color };
        return mat;
    }

    private static void MakePart(string name, Transform parent, Vector3 pos, Vector3 scale, Material mat)
    {
        var part = GameObject.CreatePrimitive(PrimitiveType.Cube);
        part.name = name;
        part.transform.SetParent(parent, false);
        part.transform.localPosition = pos;
        part.transform.localScale = scale;
        part.GetComponent<Renderer>().sharedMaterial = mat;
        Object.DestroyImmediate(part.GetComponent<Collider>());
    }

    private static void BuildCanvas(ArcadeCarController car)
    {
        var canvasGo = new GameObject("MobileHUD", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        var canvas = canvasGo.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasGo.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);

        if (!Object.FindObjectOfType<EventSystem>())
            new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));

        CreateControl(canvasGo.transform, car, "LEFT", HoldButton.ControlType.SteerLeft,
            new Vector2(0.12f, 0.18f), new Vector2(150, 130));
        CreateControl(canvasGo.transform, car, "RIGHT", HoldButton.ControlType.SteerRight,
            new Vector2(0.25f, 0.18f), new Vector2(150, 130));
        CreateControl(canvasGo.transform, car, "GAS", HoldButton.ControlType.Throttle,
            new Vector2(0.88f, 0.20f), new Vector2(170, 150));
        CreateControl(canvasGo.transform, car, "BRAKE", HoldButton.ControlType.Brake,
            new Vector2(0.75f, 0.14f), new Vector2(145, 115));
        CreateControl(canvasGo.transform, car, "HANDBRAKE", HoldButton.ControlType.Handbrake,
            new Vector2(0.75f, 0.29f), new Vector2(145, 90));

        var speedGo = new GameObject("SpeedText", typeof(RectTransform), typeof(TextMeshProUGUI));
        speedGo.transform.SetParent(canvasGo.transform, false);
        var rt = speedGo.GetComponent<RectTransform>();
        rt.anchorMin = rt.anchorMax = new Vector2(0.88f, 0.88f);
        rt.anchoredPosition = Vector2.zero;
        rt.sizeDelta = new Vector2(250, 90);
        var tmp = speedGo.GetComponent<TextMeshProUGUI>();
        tmp.text = "000";
        tmp.fontSize = 64;
        tmp.alignment = TextAlignmentOptions.Center;
        tmp.color = Color.white;
        var speed = speedGo.AddComponent<SpeedometerUI>();
        speed.car = car;
        speed.speedText = tmp;
    }

    private static void CreateControl(Transform parent, ArcadeCarController car,
        string label, HoldButton.ControlType type, Vector2 anchor, Vector2 size)
    {
        var go = new GameObject(label, typeof(RectTransform), typeof(Image), typeof(Button), typeof(HoldButton));
        go.transform.SetParent(parent, false);
        var rt = go.GetComponent<RectTransform>();
        rt.anchorMin = rt.anchorMax = anchor;
        rt.anchoredPosition = Vector2.zero;
        rt.sizeDelta = size;

        var image = go.GetComponent<Image>();
        image.color = new Color(0.05f, 0.08f, 0.12f, 0.58f);
        var hold = go.GetComponent<HoldButton>();
        hold.car = car;
        hold.controlType = type;

        var textGo = new GameObject("Label", typeof(RectTransform), typeof(Text));
        textGo.transform.SetParent(go.transform, false);
        var textRt = textGo.GetComponent<RectTransform>();
        textRt.anchorMin = Vector2.zero;
        textRt.anchorMax = Vector2.one;
        textRt.offsetMin = textRt.offsetMax = Vector2.zero;
        var uiText = textGo.GetComponent<Text>();
        uiText.text = label;
        uiText.alignment = TextAnchor.MiddleCenter;
        uiText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        uiText.fontSize = 26;
        uiText.color = Color.white;
    }
}
#endif
