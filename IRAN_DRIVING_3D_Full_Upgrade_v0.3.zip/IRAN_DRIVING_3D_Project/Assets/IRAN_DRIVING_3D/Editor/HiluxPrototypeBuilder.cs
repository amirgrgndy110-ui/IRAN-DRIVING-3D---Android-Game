#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using IranDriving3D;

public static class HiluxPrototypeBuilder
{
    [MenuItem("IRAN DRIVING 3D/Create Hilux Prototype")]
    public static void Create()
    {
        Material red = Mat("Hilux_Test_Paint", new Color(0.55f, 0.08f, 0.045f));
        Material glass = Mat("Hilux_Test_Glass", new Color(0.08f, 0.13f, 0.17f));
        Material rubber = Mat("Hilux_Test_Rubber", new Color(0.025f, 0.025f, 0.03f));
        Material metal = Mat("Hilux_Test_Metal", new Color(0.35f, 0.37f, 0.39f));

        GameObject root = new GameObject("Hilux_Prototype");
        root.transform.position = Vector3.up * 1.0f;
        Rigidbody rb = root.AddComponent<Rigidbody>();
        rb.mass = 2100f;
        rb.drag = 0.025f;
        rb.angularDrag = 0.65f;
        rb.centerOfMass = new Vector3(0f, -0.45f, 0f);

        Part("Chassis", root.transform, new Vector3(0f, 0.55f, 0f),
            new Vector3(1.95f, 0.48f, 4.9f), metal);
        Part("Cabin", root.transform, new Vector3(0f, 1.25f, -0.45f),
            new Vector3(1.82f, 1.15f, 2.15f), red);
        Part("Windshield", root.transform, new Vector3(0f, 1.48f, 0.67f),
            new Vector3(1.62f, 0.72f, 0.035f), glass);
        Part("CargoBed", root.transform, new Vector3(0f, 0.98f, -1.72f),
            new Vector3(1.78f, 0.28f, 1.55f), red);
        Part("FrontBumper", root.transform, new Vector3(0f, 0.48f, 2.48f),
            new Vector3(2.0f, 0.22f, 0.16f), metal);

        Vector3[] p = {
            new Vector3(-0.98f, 0.15f, 1.65f), new Vector3(0.98f, 0.15f, 1.65f),
            new Vector3(-0.98f, 0.15f, -1.65f), new Vector3(0.98f, 0.15f, -1.65f)
        };
        WheelCollider[] wc = new WheelCollider[4];
        Transform[] meshes = new Transform[4];

        for (int i = 0; i < 4; i++)
        {
            GameObject col = new GameObject("WheelCollider_" + i);
            col.transform.SetParent(root.transform, false);
            col.transform.localPosition = p[i];
            WheelCollider w = col.AddComponent<WheelCollider>();
            w.radius = 0.39f;
            w.mass = 24f;
            w.suspensionDistance = 0.22f;
            JointSpring spring = w.suspensionSpring;
            spring.spring = 42000f;
            spring.damper = 5200f;
            spring.targetPosition = 0.5f;
            w.suspensionSpring = spring;
            w.wheelDampingRate = 1.2f;
            wc[i] = w;

            GameObject tire = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            tire.name = "WheelVisual_" + i;
            tire.transform.SetParent(root.transform, false);
            tire.transform.localPosition = p[i];
            tire.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
            tire.transform.localScale = new Vector3(0.78f, 0.22f, 0.78f);
            tire.GetComponent<Renderer>().sharedMaterial = rubber;
            Object.DestroyImmediate(tire.GetComponent<Collider>());
            meshes[i] = tire.transform;
        }

        ArcadeCarController ctrl = root.AddComponent<ArcadeCarController>();
        ctrl.vehicleMass = 2100f;
        ctrl.frontLeft = wc[0]; ctrl.frontRight = wc[1];
        ctrl.rearLeft = wc[2]; ctrl.rearRight = wc[3];
        ctrl.frontLeftMesh = meshes[0]; ctrl.frontRightMesh = meshes[1];
        ctrl.rearLeftMesh = meshes[2]; ctrl.rearRightMesh = meshes[3];

        Selection.activeGameObject = root;
        Undo.RegisterCreatedObjectUndo(root, "Create Hilux Prototype");
        Debug.Log("Hilux prototype created. Tune WheelCollider and suspension settings for your chosen 3D model.");
    }

    private static Material Mat(string name, Color color)
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (!shader) shader = Shader.Find("Standard");
        return new Material(shader) { name = name, color = color };
    }

    private static void Part(string name, Transform parent, Vector3 pos, Vector3 scale, Material mat)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = name;
        go.transform.SetParent(parent, false);
        go.transform.localPosition = pos;
        go.transform.localScale = scale;
        go.GetComponent<Renderer>().sharedMaterial = mat;
    }
}
#endif
